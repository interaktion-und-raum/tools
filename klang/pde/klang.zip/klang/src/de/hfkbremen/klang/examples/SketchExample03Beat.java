package de.hfkbremen.klang.examples;

public class SketchExample03Beat {

}
