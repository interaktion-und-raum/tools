package de.hfkbremen.klang.examples;

/**
 * his examples shows how to use musical scales. there are a selection of predefined scales but custom ones can also be
 * created.
 */
public class SketchExample02Scales {
    // todo
}
