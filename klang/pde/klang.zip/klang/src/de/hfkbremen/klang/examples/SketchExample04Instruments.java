package de.hfkbremen.klang.examples;

/**
 * this examples shows how to use different instruments.
 */
public class SketchExample04Instruments {
    // todo
}
