package de.hfkbremen.ton.examples;

import processing.core.PApplet;

public class SketchExample21ADSRWithCustomGUI extends PApplet {
/* @TODO */
    public void settings() {
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(SketchExample21ADSRWithCustomGUI.class.getName());
    }
}
