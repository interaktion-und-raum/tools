package de.hfkbremen.ton;

public interface AudioBufferRenderer {
    void render(float[] pSamples);
}
