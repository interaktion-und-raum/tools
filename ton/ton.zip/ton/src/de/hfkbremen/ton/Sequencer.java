package de.hfkbremen.ton;

public class Sequencer {

    public Sequencer(int pSteps) {
    }
}
