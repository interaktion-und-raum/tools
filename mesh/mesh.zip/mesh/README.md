# mesh

a collection of methods to create meshes

## dependencies

* [Java 3DTM](https://java3d.java.net) (tested with 1.5.2)
* [Computational Geometry Algorithms Library (CGAL)](http://www.cgal.org) installed via [Homebrew](http://brew.sh) ( OS X only )
