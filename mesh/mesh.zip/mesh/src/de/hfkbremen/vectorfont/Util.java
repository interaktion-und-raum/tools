/*
 * Vectorfont Plugin for Gestalt
 *
 * * Copyright (C) 2011 The Product GbR Kochlik + Paul
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * {@link http://www.gnu.org/licenses/lgpl.html}
 *
 */

package de.hfkbremen.vectorfont;

import com.sun.j3d.utils.geometry.GeometryInfo;
import processing.core.PVector;

import javax.media.j3d.GeometryArray;
import javax.vecmath.Point3f;
import java.util.Vector;

public class Util {

    public static final int CLOCKWISE = 1;

    public static final int COUNTERCLOCKWISE = -1;


    /*
    public static Mesh createMesh(Vector<PVector> pTriangles, final boolean pCreateNormals) {
        final float[] mVertices = werkzeug.Util.toArray3f(pTriangles);
        final float[] mNormals;
        if (pCreateNormals) {
            mNormals = new float[mVertices.length];
            mathematik.Util.createNormals(mVertices, mNormals);
        } else {
            mNormals = null;
        }
        return new Mesh(mVertices, 3,
                            null, 4,
                            null, 2,
                            mNormals,
                            Gestalt.MESH_TRIANGLES);
    }
*/

    public static Vector<PVector[]> convertToTriangles(final Vector<Vector<Vector<PVector>>> pVectors) {
        final Vector<PVector[]> myCharTriangles = new Vector<PVector[]>();
        for (int i = 0; i < pVectors.size(); i++) {
            final Vector<PVector> myVertices = new Vector<PVector>();
            final Vector<Integer> myVertivesPerShape = new Vector<Integer>();
            final Vector<Vector<PVector>> myCharacter = pVectors.get(i);
            for (int j = 0; j < myCharacter.size(); j++) {
                final Vector<PVector> myOutline = myCharacter.get(j);
                myVertivesPerShape.add(myOutline.size());
                for (PVector v : myOutline) {
                    myVertices.add(v);
                }
            }
            if (myCharacter.size() > 0) {
                myCharTriangles.add(triangulate(toArray3f(myVertices),
                                                toArray(myVertivesPerShape),
                                                new int[]{myCharacter.size()}));
            }
        }
        return myCharTriangles;
    }

    public static PVector[] triangulate(float[] theData, int[] theStripCount, int[] theContourCount) {
        final GeometryInfo myGeometryInfo = new GeometryInfo(GeometryInfo.POLYGON_ARRAY);
        myGeometryInfo.setCoordinates(theData);
        myGeometryInfo.setStripCounts(theStripCount);
        myGeometryInfo.setContourCounts(theContourCount);

        final GeometryArray myGeometryArray = myGeometryInfo.getGeometryArray();
        final PVector[] myPoints = new PVector[myGeometryArray.getValidVertexCount()];
        for (int i = 0; i < myGeometryArray.getValidVertexCount(); i++) {
            final Point3f p = new Point3f();
            myGeometryArray.getCoordinate(i, p);
            myPoints[i] = new PVector();
            myPoints[i].set(p.x, p.y, p.z);
        }

        return myPoints;
    }

    public static float[] toArray3f(final Vector<PVector> theData) {
        float[] myArray = new float[theData.size() * 3];
        for (int i = 0; i < theData.size(); i++) {
            final PVector v = theData.get(i);
            if (v != null) {
                myArray[i * 3 + 0] = v.x;
                myArray[i * 3 + 1] = v.y;
                myArray[i * 3 + 2] = v.z;
            }
        }
        return myArray;
    }

    public static final int[] toArray(final Vector<Integer> theData) {
        int[] myArray = new int[theData.size()];
        for (int i = 0; i < myArray.length; i++) {
            if (theData.get(i) != null) {
                myArray[i] = theData.get(i);
            }
        }
        return myArray;
    }

    public static Vector<PVector> convertToVertices(final Vector<Vector<Vector<PVector>>> pVectors) {
        final Vector<PVector> myCharTriangles = new Vector<PVector>();
        for (int i = 0; i < pVectors.size(); i++) {
            final Vector<PVector> myVertices = new Vector<PVector>();
            final Vector<Integer> myVertivesPerShape = new Vector<Integer>();
            final Vector<Vector<PVector>> myCharacter = pVectors.get(i);
            for (int j = 0; j < myCharacter.size(); j++) {
                final Vector<PVector> myOutline = myCharacter.get(j);
                myVertivesPerShape.add(myOutline.size());
                for (PVector v : myOutline) {
                    myVertices.add(v);
                }
            }
            if (myCharacter.size() > 0) {
                final PVector[] mTriangle = triangulate(toArray3f(myVertices),
                                                        toArray(myVertivesPerShape),
                                                        new int[]{myCharacter.size()});
                for (int j = 0; j < mTriangle.length; j++) {
                    final PVector v = mTriangle[j];
                    myCharTriangles.add(v);
                }
            }
        }
        return myCharTriangles;
    }

    public static final boolean inside2DPolygon(final PVector thePoint, final Vector<PVector> thePolygon) {
        float x = thePoint.x;
        float y = thePoint.y;

        int c = 0;
        for (int i = 0, j = thePolygon.size() - 1; i < thePolygon.size(); j = i++) {
            if ((((thePolygon.get(i).y <= y) && (y < thePolygon.get(j).y)) || ((thePolygon.get(j).y <= y) && (y < thePolygon.get(
                    i).y))) && (x < (thePolygon.get(j).x - thePolygon.get(i).x) * (y - thePolygon.get(i).y) / (thePolygon.get(
                    j).y - thePolygon.get(i).y) + thePolygon.get(i).x)) {
                c = (c + 1) % 2;
            }
        }
        return c == 1;
    }

    public static int isClockWise2D(final Vector<PVector> mPoints) {

        if (mPoints.size() < 3) {
            return (0);
        }

        int mCount = 0;
        for (int i = 0; i < mPoints.size(); i++) {
            final PVector p1 = mPoints.get(i);
            final PVector p2 = mPoints.get((i + 1) % mPoints.size());
            final PVector p3 = mPoints.get((i + 2) % mPoints.size());
            float z;
            z = (p2.x - p1.x) * (p3.y - p2.y);
            z -= (p2.y - p1.y) * (p3.x - p2.x);
            if (z < 0) {
                mCount--;
            } else if (z > 0) {
                mCount++;
            }
        }
        if (mCount > 0) {
            return (COUNTERCLOCKWISE);
        } else if (mCount < 0) {
            return (CLOCKWISE);
        } else {
            return (0);
        }
    }
}
