package de.hfkbremen.vectorfont;

import processing.core.PVector;

import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.util.Iterator;
import java.util.Vector;

public class VectorFont {

    private final Font mFont;
    private final FontRenderContext mFRC;
    private boolean mStretchToFit = false;
    private boolean mRepeat = false;
    private float mPathFlatness = 1.0f;
    private float mOutlineFlatness = 1.0f;
    private int mInsideFlag = Util.CLOCKWISE;

    public VectorFont(final String pFontName, final float mFontSize) {
        this(Font.decode(pFontName).deriveFont(Font.PLAIN, mFontSize));
    }

    public VectorFont(final Font pFont) {
        mFont = pFont;
        mFRC = new FontRenderContext(null, true, true);
    }

    public void stretch_to_fit(final boolean pStretchToFit) {
        mStretchToFit = pStretchToFit;
    }

    public void repeat(final boolean pRepeat) {
        mRepeat = pRepeat;
    }

    public Vector<Vector<Vector<PVector>>> getOutlineFromText(String text) {
        final Vector<Vector<Vector<PVector>>> myOutlines = new Vector<Vector<Vector<PVector>>>();
        final GlyphVector mVector = mFont.createGlyphVector(mFRC, text);
        for (int j = 0; j < mVector.getNumGlyphs(); j++) {
            final Shape mGlyph = mVector.getGlyphOutline(j);
            final Vector<Vector<Vector<PVector>>> mNewCharacters = VectorFont.extractOutlineFromComplexGlyph(
                    mGlyph,
                    mOutlineFlatness,
                    mInsideFlag);
            myOutlines.addAll(mNewCharacters);
        }
        return myOutlines;
    }

    public static Vector<Vector<Vector<PVector>>> extractOutlineFromComplexGlyph(final Shape pShape,
                                                                                 final float pOutlineFlatness,
                                                                                 final int pInsideFlag) {
        final Vector<Vector<Vector<PVector>>> pAllCharacters = new Vector<Vector<Vector<PVector>>>();
        final Vector<Vector<PVector>> mSingleCharacter = extractOutlineFromSimpleShape(pShape, pOutlineFlatness);
        /* add simple character or handle and split complex glyphs */
        if (mSingleCharacter.size() <= 1) {
            pAllCharacters.add(mSingleCharacter);
        } else {
            handleComplexGlyphs(mSingleCharacter, pAllCharacters, pInsideFlag);
        }
        return pAllCharacters;
    }

    public static Vector<Vector<PVector>> extractOutlineFromSimpleShape(final Shape pShape, final float pFlatness) {
        final PathIterator mIt = new FlatteningPathIterator(pShape.getPathIterator(null), pFlatness);
        final Vector<Vector<PVector>> myCharacter = new Vector<Vector<PVector>>();
        final float[] mSegment = new float[6];
        float x = 0;
        float y = 0;
        float mx = 0;
        float my = 0;
        Vector<PVector> mOutline = new Vector<PVector>();
        while (!mIt.isDone()) {
            final int mSegmentType = mIt.currentSegment(mSegment);
            switch (mSegmentType) {
                case PathIterator.SEG_MOVETO:
                    x = mx = mSegment[0];
                    y = my = mSegment[1];
                    mOutline.add(new PVector(x, y, 0.0f));
                    break;
                case PathIterator.SEG_LINETO:
                    x = mSegment[0];
                    y = mSegment[1];
                    mOutline.add(new PVector(x, y, 0.0f));
                    break;
                case PathIterator.SEG_CLOSE:
                    x = mx;
                    y = my;
                    mOutline.add(new PVector(x, y, 0.0f));
                    myCharacter.add(mOutline);
                    mOutline = new Vector<PVector>();
                    break;
            }
            mIt.next();
        }
        return myCharacter;
    }

    private static void handleComplexGlyphs(final Vector<Vector<PVector>> pSingleCharacter,
                                            final Vector<Vector<Vector<PVector>>> pAllCharacters,
                                            final int pInsideFlag) {
        /*  sort inside and outside shapes */
        final Vector<MShape> mInsideShapes = new Vector<MShape>();
        final Vector<MShape> mOutsideShapes = new Vector<MShape>();
        for (int i = 0; i < pSingleCharacter.size(); i++) {
            final Vector<PVector> mSingleShape = pSingleCharacter.get(i);
            final boolean mIsInside = Util.isClockWise2D(mSingleShape) == pInsideFlag;
            if (mIsInside) {
                mInsideShapes.add(new MShape(mIsInside, mSingleShape));
            } else {
                mOutsideShapes.add(new MShape(mIsInside, mSingleShape));
            }
        }
        /* add shapes as individual 'characters' if there is no insides */
        if (mInsideShapes.isEmpty()) {
            addMShapes(mOutsideShapes, pAllCharacters);
        } else {
            /* asign inside shapes to outside shapes */
            final Iterator<MShape> mIterator = mInsideShapes.iterator();
            while (mIterator.hasNext()) {
                final MShape mInsideShape = mIterator.next();
                mIterator.remove();
                /* check if inside shape is contained by any outside shape */
                boolean mAddedShape = false;
                for (final MShape mOutsideShape : mOutsideShapes) {
                    /* we just query the first point of the inside shape /( hopefully this will do ) */
                    if (Util.inside2DPolygon(mInsideShape.shape.firstElement(), mOutsideShape.shape)) {
                        mOutsideShape.inside_shape.add(mInsideShape);
                        mAddedShape = true;
                        break;
                    }
                }
                /* if we couldn t asign inside shape, turn it into an outside shape */
                if (!mAddedShape) {
                    mOutsideShapes.add(mInsideShape);
                }
            }
            /* add all outside shapes */
            addMShapes(mOutsideShapes, pAllCharacters);
        }
    }

    private static void addMShapes(final Vector<MShape> pShapes, final Vector<Vector<Vector<PVector>>> pAllCharacters) {
        for (final MShape mMasterShape : pShapes) {
            final Vector<Vector<PVector>> mSimpleCharacter = new Vector<Vector<PVector>>();
            mSimpleCharacter.add(mMasterShape.shape);
            /* add inside shapes */
            if (!mMasterShape.inside_shape.isEmpty()) {
                for (final MShape mInsideShape : mMasterShape.inside_shape) {
                    mSimpleCharacter.add(mInsideShape.shape);
                }
            }
            pAllCharacters.add(mSimpleCharacter);
        }
    }

    public int insideFlag(final int pInsideFlag) {
        mInsideFlag = pInsideFlag;
        return mInsideFlag;
    }

    public GeneralPath getOutlineFromTextOnPathJAVA2D(final Shape mPath, final String pText) {

        final GlyphVector mGlyphVector = mFont.createGlyphVector(mFRC, pText);

        final GeneralPath mResult = new GeneralPath();
        final PathIterator it = new FlatteningPathIterator(mPath.getPathIterator(null), mPathFlatness);
        float mPoints[] = new float[6];
        float moveX = 0, moveY = 0;
        float lastX = 0, lastY = 0;
        float thisX = 0, thisY = 0;
        int type = 0;
        float next = 0;
        int currentChar = 0;
        int length = mGlyphVector.getNumGlyphs();

        if (length == 0) {
            return mResult;
        }

        float factor = mStretchToFit ? measurePathLength(mPath,
                                                         mPathFlatness) / (float) mGlyphVector.getLogicalBounds().getWidth() : 1.0f;
        float nextAdvance = 0;

        while (currentChar < length && !it.isDone()) {
            type = it.currentSegment(mPoints);
            switch (type) {
                case PathIterator.SEG_MOVETO:
                    moveX = lastX = mPoints[0];
                    moveY = lastY = mPoints[1];
                    mResult.moveTo(moveX, moveY);
                    nextAdvance = mGlyphVector.getGlyphMetrics(currentChar).getAdvance() * 0.5f;
                    next = nextAdvance;
                    break;

                case PathIterator.SEG_CLOSE:
                    mPoints[0] = moveX;
                    mPoints[1] = moveY;
                /* fall through */

                case PathIterator.SEG_LINETO:
                    thisX = mPoints[0];
                    thisY = mPoints[1];
                    float dx = thisX - lastX;
                    float dy = thisY - lastY;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);
                    if (distance >= next) {
                        float r = 1.0f / distance;
                        float angle = (float) Math.atan2(dy, dx);
                        while (currentChar < length && distance >= next) {
                            Shape glyph = mGlyphVector.getGlyphOutline(currentChar);
                            Point2D p = mGlyphVector.getGlyphPosition(currentChar);
                            float px = (float) p.getX();
                            float py = (float) p.getY();
                            float x = lastX + next * dx * r;
                            float y = lastY + next * dy * r;
                            float advance = nextAdvance;
                            nextAdvance = currentChar < length - 1 ? mGlyphVector.getGlyphMetrics(currentChar + 1).getAdvance() * 0.5f : 0;
                            final AffineTransform mTransform = new AffineTransform();
                            mTransform.setToTranslation(x, y);
                            mTransform.rotate(angle);
                            mTransform.translate(-px - advance, -py);
                            mResult.append(mTransform.createTransformedShape(glyph), false);
                            next += (advance + nextAdvance) * factor;
                            currentChar++;
                            if (mRepeat) {
                                currentChar %= length;
                            }
                        }
                    }
                    next -= distance;
                    lastX = thisX;
                    lastY = thisY;
                    break;
            }
            it.next();
        }

        return mResult;
    }

    private static float measurePathLength(final Shape shape, final float pPathFlatness) {
        PathIterator it = new FlatteningPathIterator(shape.getPathIterator(null), pPathFlatness);
        float points[] = new float[6];
        float moveX = 0, moveY = 0;
        float lastX = 0, lastY = 0;
        float thisX = 0, thisY = 0;
        int type = 0;
        float total = 0;

        while (!it.isDone()) {
            type = it.currentSegment(points);
            switch (type) {
                case PathIterator.SEG_MOVETO:
                    moveX = lastX = points[0];
                    moveY = lastY = points[1];
                    break;

                case PathIterator.SEG_CLOSE:
                    points[0] = moveX;
                    points[1] = moveY;
                    // Fall into....

                case PathIterator.SEG_LINETO:
                    thisX = points[0];
                    thisY = points[1];
                    float dx = thisX - lastX;
                    float dy = thisY - lastY;
                    total += (float) Math.sqrt(dx * dx + dy * dy);
                    lastX = thisX;
                    lastY = thisY;
                    break;
            }
            it.next();
        }

        return total;
    }

    public GeneralPath createShapeFromPoints2D(final Vector<PVector> pPoints) {
        final GeneralPath mPath = new GeneralPath();
        if (pPoints.isEmpty()) {
            return mPath;
        }
        mPath.moveTo(pPoints.firstElement().x, pPoints.firstElement().y);
        if (pPoints.size() > 1) {
            for (int i = 1; i < pPoints.size(); i++) {
                final PVector v = pPoints.get(i);
                mPath.lineTo(v.x, v.y);
            }
        }
        return mPath;
    }

    public GeneralPath createShapeFromPoints(final Vector<PVector> pPoints) {
        final GeneralPath mPath = new GeneralPath();
        if (pPoints.isEmpty()) {
            return mPath;
        }
        mPath.moveTo(pPoints.firstElement().x, pPoints.firstElement().y);
        if (pPoints.size() > 1) {
            for (int i = 1; i < pPoints.size(); i++) {
                final PVector v = pPoints.get(i);
                mPath.lineTo(v.x, v.y);
            }
        }
        return mPath;
    }

    public Vector<Vector<Vector<PVector>>> getOutlineFromTextOnPath(final Shape mPath, final String pText) {
        final Vector<Vector<Vector<PVector>>> mAllCharacters = new Vector<Vector<Vector<PVector>>>();
        final GlyphVector mGlyphVector = mFont.createGlyphVector(mFRC, pText);
        final PathIterator it = new FlatteningPathIterator(mPath.getPathIterator(null), mPathFlatness);
        float mPoints[] = new float[6];
        float moveX = 0, moveY = 0;
        float lastX = 0, lastY = 0;
        float mThisX = 0, mThisY = 0;
        int type = 0;
        float mNext = 0;
        int mCurrentCharID = 0;
        int mNumberOfGlyphs = mGlyphVector.getNumGlyphs();

        if (mNumberOfGlyphs == 0) {
            return mAllCharacters;
        }

        float factor = mStretchToFit ? measurePathLength(mPath,
                                                         mPathFlatness) / (float) mGlyphVector.getLogicalBounds().getWidth() : 1.0f;
        float nextAdvance = 0;

        while (mCurrentCharID < mNumberOfGlyphs && !it.isDone()) {
            type = it.currentSegment(mPoints);
            switch (type) {
                case PathIterator.SEG_MOVETO:
                    moveX = lastX = mPoints[0];
                    moveY = lastY = mPoints[1];
                    nextAdvance = mGlyphVector.getGlyphMetrics(mCurrentCharID).getAdvance() * 0.5f;
                    mNext = nextAdvance;
                    break;

                case PathIterator.SEG_CLOSE:
                    mPoints[0] = moveX;
                    mPoints[1] = moveY;
                /* fall through */

                case PathIterator.SEG_LINETO:
                    mThisX = mPoints[0];
                    mThisY = mPoints[1];
                    final float dx = mThisX - lastX;
                    final float dy = mThisY - lastY;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);
                    if (distance >= mNext) {
                        float r = 1.0f / distance;
                        float angle = (float) Math.atan2(dy, dx);
                        while (mCurrentCharID < mNumberOfGlyphs && distance >= mNext) {
                            final Shape mGlyph = mGlyphVector.getGlyphOutline(mCurrentCharID);
                            final Point2D p = mGlyphVector.getGlyphPosition(mCurrentCharID);
                            final float px = (float) p.getX();
                            final float py = (float) p.getY();
                            final float x = lastX + mNext * dx * r;
                            final float y = lastY + mNext * dy * r;
                            final float advance = nextAdvance;
                            nextAdvance = mCurrentCharID < mNumberOfGlyphs - 1 ? mGlyphVector.getGlyphMetrics(
                                    mCurrentCharID + 1).getAdvance() * 0.5f : 0;
                            final AffineTransform mTransform = new AffineTransform();
                            mTransform.setToTranslation(x, y);
                            mTransform.rotate(angle);
                            mTransform.translate(-px - advance, -py);

                            /* extract outlines */
                            final Shape mShape = mTransform.createTransformedShape(mGlyph);
                            final Vector<Vector<Vector<PVector>>> mNewCharacters = extractOutlineFromComplexGlyph(mShape,
                                                                                                                  mOutlineFlatness,
                                                                                                                  mInsideFlag);
                            mAllCharacters.addAll(mNewCharacters);
                            mNext += (advance + nextAdvance) * factor;
                            mCurrentCharID++;
                            if (mRepeat) {
                                mCurrentCharID %= mNumberOfGlyphs;
                            }
                        }
                    }
                    mNext -= distance;
                    lastX = mThisX;
                    lastY = mThisY;
                    break;
            }
            it.next();
        }
        return mAllCharacters;
    }

    public void outline_flatness(float pOutlineFlatness) {
        mOutlineFlatness = pOutlineFlatness;
    }

    public void path_flatness(float pPathFlatness) {
        mPathFlatness = pPathFlatness;
    }

    public static Vector<PVector[]> convertToTriangles(Vector<Vector<Vector<PVector>>> mWordOutlines) {
        return Util.convertToTriangles(mWordOutlines);
    }

    private static class MShape {

        final boolean inside;

        final Vector<PVector> shape;

        final Vector<MShape> inside_shape;

        private MShape(final boolean pInside, final Vector<PVector> pShape) {
            inside = pInside;
            shape = pShape;
            inside_shape = new Vector<MShape>();
        }
    }
}
