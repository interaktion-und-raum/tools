package de.hfkbremen.mesh.examples;

import de.hfkbremen.mesh.Mesh;
import de.hfkbremen.mesh.ModelData;
import de.hfkbremen.mesh.ModelLoaderOBJ;
import de.hfkbremen.mesh.OBJWeirdObject;
import processing.core.PApplet;

public class SketchLoadingOBJModels extends PApplet {

    private Mesh mModelMesh;

    public void settings() {
        size(640, 480, P3D);
    }

    public void setup() {
        ModelData myModelData = ModelLoaderOBJ.getModelData(OBJWeirdObject.DATA);
        mModelMesh = myModelData.createMesh();
        println(myModelData);
    }

    public void draw() {
        background(255);

        if (mousePressed) {
            noFill();
            stroke(0);
            mModelMesh.primitive(POINTS);
        } else {
            fill(0, 127, 255);
            stroke(255);
            mModelMesh.primitive(TRIANGLES);
        }

        translate(width / 2, height / 2, -200);
        rotateX(sin(frameCount * 0.01f) * TWO_PI);
        rotateY(cos(frameCount * 0.0037f) * TWO_PI);

        mModelMesh.draw(g);
    }

    public static void main(String[] args) {
        PApplet.main(SketchLoadingOBJModels.class.getName());
    }
}
