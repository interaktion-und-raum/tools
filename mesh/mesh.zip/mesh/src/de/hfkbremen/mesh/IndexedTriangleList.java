package de.hfkbremen.mesh;

import processing.core.PVector;

import java.util.ArrayList;

public class IndexedTriangleList {

    public ArrayList<PVector> positions = new ArrayList<>();
    public ArrayList<Integer> triangle_indices = new ArrayList<>();

}
