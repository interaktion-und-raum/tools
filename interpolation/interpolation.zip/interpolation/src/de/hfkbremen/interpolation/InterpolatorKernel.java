package de.hfkbremen.interpolation;

public interface InterpolatorKernel {

    public float get(final float theDelta);
}
