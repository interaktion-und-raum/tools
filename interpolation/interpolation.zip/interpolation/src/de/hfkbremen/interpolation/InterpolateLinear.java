package de.hfkbremen.interpolation;

public class InterpolateLinear implements InterpolatorKernel {

    public float get(final float theDelta) {
        return theDelta;
    }
}
