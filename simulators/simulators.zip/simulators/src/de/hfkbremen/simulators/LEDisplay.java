package de.hfkbremen.simulators;

public class LEDisplay {
    /* a pixel patch represented as LEDs */
}
