package de.hfkbremen.simulators.examples;

import processing.core.PApplet;
import static processing.core.PConstants.P3D;

public class SketchScreenOn3DObject extends PApplet {

    public void settings() {
        size(1024, 768, P3D);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(SketchScreenOn3DObject.class.getName());
    }
}
