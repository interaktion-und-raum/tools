package de.hfkbremen.simulators.examples;

import processing.core.PApplet;

public class SketchScreenOn3DObject extends PApplet {

    //@TODO

    public void settings() {
        size(1024, 768, P3D);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(SketchScreenOn3DObject.class.getName());
    }
}
