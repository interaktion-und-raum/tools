package de.hfkbremen.simulators.examples;

import de.hfkbremen.simulators.OffscreenContext;
import processing.core.PApplet;
import processing.core.PGraphics;

public class MyScreen extends OffscreenContext {

    public MyScreen(PApplet pParent) {
        super(pParent);
    }

    public void settings() {
        size(640, 480);
    }

    public void setup(PGraphics graphics) {
        /* call processing methods with a `p.` e.g `p.frameCount` */
        graphics.background(255);
        /* call processing drawing methods with a `graphics.` e.g `graphics.point(float, float)` */
    }

    public void draw(PGraphics graphics) {
        graphics.stroke(0);
        float mY = parent.random(0, graphics.height);
        graphics.line(
                parent.random(0, graphics.width), mY,
                parent.random(0, graphics.width), mY
        );
    }
}
