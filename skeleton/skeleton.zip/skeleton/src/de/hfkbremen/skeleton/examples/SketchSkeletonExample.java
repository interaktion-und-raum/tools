package de.hfkbremen.skeleton.examples;

import processing.core.PApplet;
import processing.core.PVector;

public class SketchSkeletonExample extends PApplet {

   	private ArrayList<PVector> mList = new ArrayList<>();

    public void settings() {
        size(640, 480);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(SketchSkeletonExample.class.getName());
    }
}
