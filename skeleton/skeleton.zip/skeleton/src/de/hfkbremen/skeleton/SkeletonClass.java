package de.hfkbremen.skeleton;

public class SkeletonClass {

    public SkeletonClass() {
    }
}
