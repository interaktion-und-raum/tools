package de.hfkbremen.synthesizer.examples;

public class SketchExample03Beat {

}
