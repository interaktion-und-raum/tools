package de.hfkbremen.synthesizer.examples;

public class SketchExample02Instruments {

}
