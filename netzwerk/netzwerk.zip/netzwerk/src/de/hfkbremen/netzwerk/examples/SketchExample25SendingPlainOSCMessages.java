package de.hfkbremen.netzwerk.examples;

public class SketchExample25SendingPlainOSCMessages {

}
