package de.hfkbremen.netzwerk.examples;

import processing.core.PApplet;
import processing.core.PVector;

public class SketchSkeletonExample extends PApplet {

    public void settings() {
        size(640, 480);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(SketchSkeletonExample.class.getName());
    }
}
