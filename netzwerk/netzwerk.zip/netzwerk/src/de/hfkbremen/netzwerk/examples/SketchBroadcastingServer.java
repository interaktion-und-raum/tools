package de.hfkbremen.netzwerk.examples;

import de.hfkbremen.netzwerk.AppBroadcastingServer;
import processing.core.PApplet;

public class SketchBroadcastingServer extends PApplet {

    public void settings() {
        size(1, 1);
    }

    public void setup() {
        main(AppBroadcastingServer.class.getName());
    }

    public static void main(String[] args) {
        PApplet.main(AppBroadcastingServer.class.getName());
    }
}
