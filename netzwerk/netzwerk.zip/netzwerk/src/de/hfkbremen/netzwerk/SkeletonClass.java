package de.hfkbremen.netzwerk;

public class SkeletonClass {

    public SkeletonClass() {
    }
}
