package de.hfkbremen.filter;

public interface Filter {

    void add_sample(float pSample);

    float get();
}
